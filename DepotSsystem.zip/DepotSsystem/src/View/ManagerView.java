package View;

import Model.Log;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ManagerView extends JFrame {
    private JTable parcelsTable;
    private JTable customerQueueTable;
    private JTextArea currentParcelDetails;
    private JButton processButton, loadDataButton, addCustomerButton, addParcelButton;

    public ManagerView() {
        setTitle("Depot Manager Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLayout(new BorderLayout(15, 15));

        // Header
        JLabel header = new JLabel("Depot Management System", JLabel.CENTER);
        header.setFont(new Font("Verdana", Font.BOLD, 28));
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(header, BorderLayout.NORTH);

        // Main Content Panel
        JPanel mainContent = new JPanel(new GridLayout(2, 1, 10, 10));
        add(mainContent, BorderLayout.CENTER);

        // Top Section with Parcels and Customer Queue
        JPanel topSection = new JPanel(new GridLayout(1, 2, 15, 15));

        // Parcels Panel
        JPanel parcelsPanel = new JPanel(new BorderLayout());
        parcelsPanel.setBorder(BorderFactory.createTitledBorder("Parcels"));
        parcelsTable = new JTable(new DefaultTableModel(new String[]{"Parcel ID", "Weight", "Destination", "Days in Depot", "Fee"}, 0));
        parcelsPanel.add(new JScrollPane(parcelsTable), BorderLayout.CENTER);
        topSection.add(parcelsPanel);

        // Customer Queue Panel
        JPanel customerQueuePanel = new JPanel(new BorderLayout());
        customerQueuePanel.setBorder(BorderFactory.createTitledBorder("Customer Queue"));
        customerQueueTable = new JTable(new DefaultTableModel(new String[]{"Customer ID", "Name", "Parcel ID"}, 0));
        customerQueuePanel.add(new JScrollPane(customerQueueTable), BorderLayout.CENTER);
        topSection.add(customerQueuePanel);

        mainContent.add(topSection);

        // Bottom Section with Current Parcel Details
        JPanel bottomSection = new JPanel(new BorderLayout());
        bottomSection.setBorder(BorderFactory.createTitledBorder("Current Parcel Details"));
        currentParcelDetails = new JTextArea(5, 20);
        currentParcelDetails.setEditable(false);
        currentParcelDetails.setLineWrap(true);
        currentParcelDetails.setWrapStyleWord(true);
        bottomSection.add(new JScrollPane(currentParcelDetails), BorderLayout.CENTER);
        mainContent.add(bottomSection);

        // Footer Panel
        JPanel footerPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        processButton = new JButton("Next Customer in Queue");
        loadDataButton = new JButton("Load All Data");
        addCustomerButton = new JButton("Add Customer");
        addParcelButton = new JButton("Add Parcel");
        JButton sortButton = new JButton("Sort by Last Name");

        footerPanel.add(loadDataButton);
        footerPanel.add(processButton);
        footerPanel.add(addCustomerButton);
        footerPanel.add(addParcelButton);
        footerPanel.add(sortButton);

        add(footerPanel, BorderLayout.SOUTH);

        // Sort Button Action
        sortButton.addActionListener(e -> {
            ManagerController controller = new ManagerController(this);
            controller.sortParcelsByLastName();
        });

        setVisible(true);
    }

    // Getters for buttons and table models
    public JButton getProcessButton() {
        return processButton;
    }

    public JButton getLoadDataButton() {
        return loadDataButton;
    }

    public JButton getAddCustomerButton() {
        return addCustomerButton;
    }

    public JButton getAddParcelButton() {
        return addParcelButton;
    }

    public DefaultTableModel getParcelsTableModel() {
        return (DefaultTableModel) parcelsTable.getModel();
    }

    public DefaultTableModel getCustomerQueueTableModel() {
        return (DefaultTableModel) customerQueueTable.getModel();
    }

    public JTextArea getCurrentParcelDetails() {
        return currentParcelDetails;
    }

    public static void main(String[] args) {
        ManagerView view = new ManagerView();
        new ManagerController(view);
    }
}

class ManagerController {

    private ManagerView view;

    public ManagerController(ManagerView view) {
        this.view = view;

        // Add listeners to buttons
        view.getLoadDataButton().addActionListener(e -> loadDataFromCSV());
        view.getProcessButton().addActionListener(e -> processNextCustomer());
        view.getAddCustomerButton().addActionListener(e -> addNewCustomer());
        view.getAddParcelButton().addActionListener(e -> addNewParcel());
    }

    private double calculateFee(double weight) {
        double baseFee = 5.0;
        double weightRate = 2.0;
        return Math.round((baseFee + (weight * weightRate)) * 100.0) / 100.0;
    }

    private void loadDataFromCSV() {
        String parcelsFilePath = "Parcels.csv";
        String customersFilePath = "Custs.csv";

        DefaultTableModel parcelsModel = view.getParcelsTableModel();
        DefaultTableModel customerQueueModel = view.getCustomerQueueTableModel();

        // Clear existing data
        parcelsModel.setRowCount(0);
        customerQueueModel.setRowCount(0);

        // Load parcels data from CSV
        try (BufferedReader br = new BufferedReader(new FileReader(parcelsFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4) {
                    String parcelID = data[0];
                    String weight = data[1];
                    String destination = data[2];
                    String processed = data[3];
                    double fee = calculateFee(Double.parseDouble(weight.replace("kg", "").trim()));
                    parcelsModel.addRow(new Object[]{parcelID, weight, destination, processed, fee});
                } else {
                    Log.getInstance().logEvent("Skipping invalid parcel data: " + line);
                }
            }
            Log.getInstance().logEvent("Parcels data loaded successfully.");
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(view, "Error loading parcels data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            Log.getInstance().logEvent("Error loading parcels data: " + e.getMessage());
        }

        // Load customer queue data from CSV
        try (BufferedReader br = new BufferedReader(new FileReader(customersFilePath))) {
            String line;
            int customerIDCounter = 100; // Start assigning 3-digit IDs from 100
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 2) {
                    String customerName = data[0].trim();
                    String parcelID = data[1].trim();
                    String customerID = String.valueOf(customerIDCounter++);

                    customerQueueModel.addRow(new Object[]{customerID, customerName, parcelID});
                    Log.getInstance().logEvent("Loaded customer: " + customerID + ", " + customerName + ", " + parcelID);
                } else {
                    Log.getInstance().logEvent("Skipping invalid customer data: " + line);
                }
            }
            Log.getInstance().logEvent("Customer data loaded successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(view, "Error loading customer queue data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            Log.getInstance().logEvent("Error loading customer queue data: " + e.getMessage());
        }

        Log.getInstance().logEvent("Data loaded from CSV: parcels and customers.");
        view.getProcessButton().setEnabled(customerQueueModel.getRowCount() > 0);
    }

    private void addNewCustomer() {
        String customerID = JOptionPane.showInputDialog(view, "Enter customer ID");
        String customerName = JOptionPane.showInputDialog(view, "Enter customer name");
        String parcelID = JOptionPane.showInputDialog(view, "Enter parcel ID");

        if (customerID != null && customerName != null && parcelID != null) {
            DefaultTableModel customerQueueModel = view.getCustomerQueueTableModel();
            customerQueueModel.addRow(new Object[]{customerID, customerName, parcelID});
            Log.getInstance().logEvent("New customer added: " + customerName + " (Customer ID: " + customerID + ")");
        } else {
            JOptionPane.showMessageDialog(view, "Enter customer ID and customer name", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addNewParcel() {
        String parcelID = JOptionPane.showInputDialog(view, "Enter parcel ID");
        String weightStr = JOptionPane.showInputDialog(view, "Enter parcel weight");
        String destination = JOptionPane.showInputDialog(view, "Enter parcel destination");

        if (parcelID != null && weightStr != null && destination != null) {
            try {
                double weight = Double.parseDouble(weightStr);
                double fee = calculateFee(weight);
                DefaultTableModel parcelsModel = view.getParcelsTableModel();
                parcelsModel.addRow(new Object[]{parcelID, weight + "kg", destination, "no", fee});
                Log.getInstance().logEvent("New Parcel added: " + parcelID + " (Weight: " + weight + "kg, Destination: " + destination + ")");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Invalid weight input", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(view, "All fields are required", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void sortParcelsByLastName() {
    DefaultTableModel customerQueueModel = view.getCustomerQueueTableModel();
    List<Object[]> rows = new ArrayList<>();

    // Gather data from the table
    for (int i = 0; i < customerQueueModel.getRowCount(); i++) {
        rows.add(new Object[]{
            customerQueueModel.getValueAt(i, 0),
            customerQueueModel.getValueAt(i, 1),
            customerQueueModel.getValueAt(i, 2)
        });
    }

    // Sort rows by last name (assuming the Name column is at index 1)
    rows.sort((a, b) -> {
        String lastNameA = ((String) a[1]).split(" ")[1];
        String lastNameB = ((String) b[1]).split(" ")[1];
        return lastNameA.compareToIgnoreCase(lastNameB);
    });

    // Clear and repopulate the table
    customerQueueModel.setRowCount(0);
    for (Object[] row : rows) {
        customerQueueModel.addRow(row);
    }

    Log.getInstance().logEvent("Customer queue sorted by last name.");
    JOptionPane.showMessageDialog(view, "Customer queue sorted by last name.", "Info", JOptionPane.INFORMATION_MESSAGE);
}

    private void processNextCustomer() {
        DefaultTableModel parcelsModel = view.getParcelsTableModel();
        DefaultTableModel customerQueueModel = view.getCustomerQueueTableModel();

        if (customerQueueModel.getRowCount() > 0) {
            // Remove the next customer from queue
            String customerID = (String) customerQueueModel.getValueAt(0, 0);
            String customerName = (String) customerQueueModel.getValueAt(0, 1);
            String parcelID = (String) customerQueueModel.getValueAt(0, 2);
            customerQueueModel.removeRow(0);

            // Update parcel as processed
            for (int i = 0; i < parcelsModel.getRowCount(); i++) {
                if (parcelsModel.getValueAt(i, 0).equals(parcelID)) {
                    parcelsModel.setValueAt("Yes", i, 3);
                    break;
                }
            }
            // Update current parcel details
            view.getCurrentParcelDetails().setText("Customer ID: " + customerID +
                    "\nCustomer Name: " + customerName +
                    "\nParcel ID: " + parcelID +
                    "\nStatus: Processed");
            Log.getInstance().logEvent("Processed customer: " + customerName + " (Customer ID: " + customerID + ") with Parcel ID: " + parcelID);
        } else {
            JOptionPane.showMessageDialog(view, "No customer left!", "Info", JOptionPane.INFORMATION_MESSAGE);
            Log.getInstance().logEvent("Attempted to process customers, but none were left in queue");
        }
    }
}