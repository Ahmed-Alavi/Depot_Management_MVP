package Control;

import Model.Log;
import Model.Customer;
import Model.ParcelMap;
import Model.Parcel;

public class Worker {

 
    public double processCustomer(Customer customer, ParcelMap parcelMap, Log log) {
        Parcel parcel = parcelMap.getParcelById(customer.getParcelId());

        if (parcel != null) {
            // Calculate the parcel fee
            double fee = parcel.calculateFee();

            // Update the parcel status to "Collected"
            parcel.setStatus("Collected");

            // Remove the parcel from the map after processing
            parcelMap.removeParcel(parcel.getId());

            // Log the processing event
            log.logEvent("Processed Customer: " + customer + ", Parcel: " + parcel + ", Fee: $" + fee);

            return fee;
        } else {
            // Log the failure to find the parcel
            log.logEvent("Parcel not found for Customer: " + customer);
            return 0.0;
        }
    }
}
