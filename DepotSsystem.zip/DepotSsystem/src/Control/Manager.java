package Control;

import Model.Log;
import Model.Customer;
import Model.QueueOfCustomers;
import Model.Parcel;
import Model.ParcelMap;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Manager {
    public static void main(String[] args) {
        ParcelMap parcelMap = new ParcelMap();
        QueueOfCustomers customerQueue = new QueueOfCustomers();
        Log log = Log.getInstance();
        Worker worker = new Worker();

        // Load data from CSV files
        String parcelsFilePath = "Parcels.csv";
        String customersFilePath = "Custs.csv";

        try (BufferedReader br = new BufferedReader(new FileReader(parcelsFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(","); 
                if (data.length >= 6) {
                    String id = data[0];
                    String dimensions = data[1];
                    double weight = Double.parseDouble(data[2]);
                    int daysInDepot = Integer.parseInt(data[3]);
                    String destination = data[4];
                    String status = data[5];
                    parcelMap.addParcel(new Parcel(id, dimensions, weight, daysInDepot, destination, status));
                } else {
                    log.logEvent("Skipping invalid parcel data: " + line);
                }
            }
            log.logEvent("Parcels loaded successfully.");
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error loading parcels data: " + e.getMessage());
        }

        try (BufferedReader br = new BufferedReader(new FileReader(customersFilePath))) {
            String line;
            int customerIDCounter = 100; // Start assigning 3-digit IDs
            while ((line = br.readLine()) != null) {
                String[] data = line.split(","); // Assuming CSV is comma-separated
                if (data.length >= 2) {
                    String customerName = data[0];
                    String parcelId = data[1];
                    customerQueue.enqueueCustomer(new Customer(customerIDCounter++, customerName, parcelId));
                } else {
                    log.logEvent("Skipping invalid customer data: " + line);
                }
            }
            log.logEvent("Customers loaded successfully.");
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error loading customers data: " + e.getMessage());
        }

        // GUI Initialization
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Depot Manager System");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1000, 700);

            JTextArea logArea = new JTextArea();
            logArea.setEditable(false);

            JButton processButton = new JButton("Process Next Customer");
            processButton.addActionListener(e -> {
                Customer customer = customerQueue.dequeueCustomer();
                if (customer != null) {
                    Parcel parcel = parcelMap.getParcelById(customer.getParcelId());
                    if (parcel != null) {
                        double fee = parcel.calculateFee();
                        parcel.setStatus("Processed");
                        log.logEvent("Processed Customer: " + customer + ", Parcel: " + parcel);
                        logArea.append("Processed Customer: " + customer + ", Parcel Fee: $" + fee + "\n");
                    } else {
                        logArea.append("Parcel not found for Customer: " + customer + "\n");
                    }
                } else {
                    logArea.append("No customers in the queue\n");
                }
            });

            frame.setLayout(new BorderLayout());
            frame.add(new JScrollPane(logArea), BorderLayout.CENTER);
            frame.add(processButton, BorderLayout.SOUTH);

            frame.setVisible(true);
        });
    }
}
