package Model;

public class Customer {
    private int seqNumber;
    private String name;
    private String parcelId;

    public Customer(int seqNumber, String name, String parcelId) {
        this.seqNumber = seqNumber;
        this.name = name;
        this.parcelId = parcelId;
    }

    @Override
    public String toString() {
        return String.format("Seq: %d, Name: %s, ParcelId: %s", seqNumber, name, parcelId);
    }

    public String getParcelId() {
        return parcelId;
    }
}
