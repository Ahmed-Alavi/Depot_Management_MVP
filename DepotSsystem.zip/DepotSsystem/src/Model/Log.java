package Model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Log {
    private static Log instance;
    private static final String LOG_FILE_PATH = "log.txt";

    private Log() {
    }

    //singleton instance
    public static synchronized Log getInstance() {
        if (instance == null) {
            instance = new Log();
        }
        return instance;
    }


    public void logEvent(String event) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE_PATH, true))) {
            writer.write(event + "\n");
        } catch (IOException e) {
        System.err.println("Failed to write log file: " + e.getMessage());
    }
}

    public String getLog() {
        try {
            return new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(LOG_FILE_PATH)));
        } catch (IOException e) {
            System.err.println("Failed to read log file: " + e.getMessage());
        return "";
        }
    }
        }

//dont change from this!!