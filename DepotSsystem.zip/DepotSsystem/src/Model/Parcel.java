package Model;

public class Parcel {
    private String id;
    private String dimensions;
    private double weight;
    private int daysInDepot;
    private String destination;
    private String status;

    public Parcel(String id, String dimensions, double weight, int daysInDepot, String destination, String status) {
        this.id = id;
        this.dimensions = dimensions;
        this.weight = weight;
        this.daysInDepot = daysInDepot;
        this.destination = destination;
        this.status = status;
    }

    public double calculateFee() {
        double baseFee = 5.0;
        double weightFee = weight * 2.0;
        double dayFee = daysInDepot * 0.5;
        return baseFee + weightFee + dayFee;
    }

    @Override
    public String toString() {
        return String.format("ID: %s, Weight: %.2f, Days: %d, Dimensions: %s, Destination: %s, Status: %s",
                id, weight, daysInDepot, dimensions, destination, status);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getDaysInDepot() {
        return daysInDepot;
    }

    public void setDaysInDepot(int daysInDepot) {
        this.daysInDepot = daysInDepot;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
